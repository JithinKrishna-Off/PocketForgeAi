//
// SPDX-FileCopyrightText: Copyright 2021, 2023, 2025-2026 Arm Limited and/or its affiliates <open-source-office@arm.com>
//
// SPDX-License-Identifier: Apache-2.0
//

// clang-format off


#include <cstddef>
#include <cstdint>

#if defined(__aarch64__)

namespace kai {
namespace ops {
namespace depthwise {

void sve_fp32_nhwc_3x3_s1_output2x2_mla_depthfirst_indirect_impl(
  const float *const *const input_ptrs,
  float *const *const outptrs,
  const void *params,
  unsigned int n_channels,
  const float activation_min,
  const float activation_max
)
{
  struct Args
  {
    float *const *outptrs;
    const void *params;
    const float min, max;
    const float *inptrs[16];

    Args(
      const float *const *const input_ptrs,
      float *const *const outptrs,
      const void *const params,
      const float min,
      const float max
    ) : outptrs(outptrs), params(params), min(min), max(max)
    {
      inptrs[0] = input_ptrs[5];
      inptrs[1] = input_ptrs[0];
      inptrs[2] = input_ptrs[3];
      inptrs[3] = input_ptrs[6];
      inptrs[4] = input_ptrs[9];
      inptrs[5] = input_ptrs[12];
      inptrs[6] = input_ptrs[15];
      inptrs[7] = input_ptrs[1];
      inptrs[8] = input_ptrs[2];
      inptrs[9] = input_ptrs[10];
      inptrs[10] = input_ptrs[4];
      inptrs[11] = input_ptrs[7];
      inptrs[12] = input_ptrs[8];
      inptrs[13] = input_ptrs[11];
      inptrs[14] = input_ptrs[13];
      inptrs[15] = input_ptrs[14];

    }
  };

  Args params_struct(input_ptrs, outptrs, params,
                     activation_min, activation_max);

  __asm__ __volatile__(
    "ptrue p3.b\n"
    "ldr x20, [%x[params_struct], %[offsetof_args_outptrs]]\n"
    "ldr x16, [%x[params_struct], %[offsetof_args_params]]\n"
    "add x15, %x[params_struct], %[offsetof_Args_inptrs]\n"
    "cntw x14\n"
    "mov x13, #0\n"
    "ldr x24, [x15, #0x20]\n"
    "whilelt p2.s, XZR, %x[n_channels]\n"
    "ldp x12, x11, [x20, #0]\n"
    "ldp x10, x9, [x20, #0x10]\n"
    "ld1w { z18.s }, p3/Z, [x16]\n"
    "ld1w { z0.s }, p3/Z, [x16, #1, MUL VL]\n"
    "ld1w { z1.s }, p3/Z, [x16, #2, MUL VL]\n"
    "ld1w { z2.s }, p3/Z, [x16, #3, MUL VL]\n"
    "cmp x14, %x[n_channels]\n"
    "sub x28, XZR, x14\n"
    "ld1w { z3.s }, p3/Z, [x16, #4, MUL VL]\n"
    "ld1w { z4.s }, p3/Z, [x16, #5, MUL VL]\n"
    "ld1w { z5.s }, p3/Z, [x16, #6, MUL VL]\n"
    "ld1w { z6.s }, p3/Z, [x16, #7, MUL VL]\n"
    "addvl x16, x16, #16\n"
    "ldp x23, x22, [x15, #0]\n"
    "ldp x21, x20, [x15, #0x10]\n"
    "ld1rw { z17.s }, p3/Z, [%x[params_struct], %[offsetof_args_min]]\n"
    "ld1rw { z16.s }, p3/Z, [%x[params_struct], %[offsetof_args_max]]\n"
    "ld1w { z7.s }, p3/Z, [x16, #-8, MUL VL]\n"
    "ld1w { z8.s }, p3/Z, [x16, #-7, MUL VL]\n"
    "addvl x16, x16, #-6\n"
    "ld1w { z9.s }, p2/Z, [x23, x13, LSL #2]\n"
    "ld1w { z10.s }, p2/Z, [x22, x13, LSL #2]\n"
    "ld1w { z11.s }, p2/Z, [x21, x13, LSL #2]\n"
    "ld1w { z12.s }, p2/Z, [x20, x13, LSL #2]\n"
    "ld1w { z13.s }, p2/Z, [x24, x13, LSL #2]\n"
    "bge 2f\n"
    "1:"  // Channel loop
    "movprfx z28, z18\n fmla z28.s, p3/M, z4.s, z9.s\n"
    "movprfx z29, z18\n fmla z29.s, p3/M, z3.s, z9.s\n"
    "ldr x21, [x15, #0x28]\n"
    "ldr x25, [x15, #0x30]\n"
    "movprfx z30, z18\n fmla z30.s, p3/M, z1.s, z9.s\n"
    "movprfx z31, z18\n fmla z31.s, p3/M, z0.s, z9.s\n"
    "ldr x24, [x15, #0x38]\n"
    "ldr x20, [x15, #0x48]\n"
    "ldr x23, [x15, #0x40]\n"
    "ldr x22, [x15, #0x50]\n"
    "whilelt p1.s, x14, %x[n_channels]\n"
    "incw x28\n"
    "ld1w { z9.s }, p2/Z, [x21, x13, LSL #2]\n"
    "ldr x21, [x15, #0x58]\n"
    "mov p0.b, p2.b\n"
    "fmla z28.s, p3/M, z0.s, z10.s\n"
    "fmla z29.s, p3/M, z2.s, z11.s\n"
    "ld1w { z11.s }, p2/Z, [x25, x13, LSL #2]\n"
    "ld1w { z10.s }, p2/Z, [x20, x13, LSL #2]\n"
    "fmla z30.s, p3/M, z2.s, z12.s\n"
    "fmla z31.s, p3/M, z1.s, z12.s\n"
    "ldr x20, [x15, #0x60]\n"
    "ldr x27, [x15, #0x68]\n"
    "ldr x26, [x15, #0x70]\n"
    "ld1w { z18.s }, p3/Z, [x16]\n"
    "fmla z28.s, p3/M, z5.s, z12.s\n"
    "fmla z29.s, p3/M, z4.s, z12.s\n"
    "ld1w { z12.s }, p2/Z, [x24, x13, LSL #2]\n"
    "ldr x25, [x15, #0x78]\n"
    "fmla z30.s, p3/M, z6.s, z9.s\n"
    "ld1w { z9.s }, p2/Z, [x23, x13, LSL #2]\n"
    "ldp x24, x23, [x15, #0]\n"
    "fmla z31.s, p3/M, z3.s, z13.s\n"
    "fmla z28.s, p3/M, z7.s, z13.s\n"
    "fmla z29.s, p3/M, z6.s, z13.s\n"
    "fmla z30.s, p3/M, z4.s, z13.s\n"
    "fmla z31.s, p3/M, z8.s, z11.s\n"
    "ld1w { z11.s }, p2/Z, [x22, x13, LSL #2]\n"
    "fmla z28.s, p3/M, z1.s, z12.s\n"
    "fmla z29.s, p3/M, z0.s, z12.s\n"
    "ld1w { z12.s }, p2/Z, [x21, x13, LSL #2]\n"
    "ldp x22, x21, [x15, #0x10]\n"
    "fmla z30.s, p3/M, z5.s, z10.s\n"
    "fmla z31.s, p3/M, z4.s, z10.s\n"
    "ld1w { z4.s }, p3/Z, [x16, #5, MUL VL]\n"
    "fmla z28.s, p3/M, z2.s, z9.s\n"
    "fmla z29.s, p3/M, z1.s, z9.s\n"
    "ld1w { z9.s }, p2/Z, [x20, x13, LSL #2]\n"
    "ldr x20, [x15, #0x20]\n"
    "ld1w { z1.s }, p3/Z, [x16, #2, MUL VL]\n"
    "fmla z30.s, p3/M, z0.s, z11.s\n"
    "ld1w { z0.s }, p3/Z, [x16, #1, MUL VL]\n"
    "fmla z31.s, p3/M, z2.s, z12.s\n"
    "ld1w { z2.s }, p3/Z, [x16, #3, MUL VL]\n"
    "fmla z28.s, p3/M, z8.s, z10.s\n"
    "ld1w { z13.s }, p1/Z, [x20, x14, LSL #2]\n"
    "fmla z29.s, p3/M, z7.s, z10.s\n"
    "ld1w { z10.s }, p2/Z, [x27, x13, LSL #2]\n"
    "fmla z30.s, p3/M, z3.s, z9.s\n"
    "fmla z31.s, p3/M, z5.s, z10.s\n"
    "fmla z28.s, p3/M, z3.s, z11.s\n"
    "ld1w { z11.s }, p2/Z, [x26, x13, LSL #2]\n"
    "ld1w { z3.s }, p3/Z, [x16, #4, MUL VL]\n"
    "fmla z29.s, p3/M, z5.s, z12.s\n"
    "ld1w { z12.s }, p2/Z, [x25, x13, LSL #2]\n"
    "incw x13\n"
    "ld1w { z5.s }, p3/Z, [x16, #6, MUL VL]\n"
    "fmla z30.s, p3/M, z7.s, z11.s\n"
    "fmla z31.s, p3/M, z6.s, z11.s\n"
    "ld1w { z11.s }, p1/Z, [x22, x14, LSL #2]\n"
    "fmla z28.s, p3/M, z6.s, z9.s\n"
    "ld1w { z9.s }, p1/Z, [x24, x14, LSL #2]\n"
    "ld1w { z6.s }, p3/Z, [x16, #7, MUL VL]\n"
    "addvl x16, x16, #16\n"
    "fmla z29.s, p3/M, z8.s, z10.s\n"
    "ld1w { z10.s }, p1/Z, [x23, x14, LSL #2]\n"
    "whilelt p2.s, x13, %x[n_channels]\n"
    "fmla z30.s, p3/M, z8.s, z12.s\n"
    "fmla z31.s, p3/M, z7.s, z12.s\n"
    "ld1w { z12.s }, p1/Z, [x21, x14, LSL #2]\n"
    "incw x14\n"
    "fmax z28.s, p3/M, z28.s, z17.s\n"
    "ld1w { z7.s }, p3/Z, [x16, #-8, MUL VL]\n"
    "ld1w { z8.s }, p3/Z, [x16, #-7, MUL VL]\n"
    "addvl x16, x16, #-6\n"
    "fmax z29.s, p3/M, z29.s, z17.s\n"
    "fmax z30.s, p3/M, z30.s, z17.s\n"
    "fmax z31.s, p3/M, z31.s, z17.s\n"
    "cmp x14, %x[n_channels]\n"
    "fmin z28.s, p3/M, z28.s, z16.s\n"
    "fmin z29.s, p3/M, z29.s, z16.s\n"
    "fmin z30.s, p3/M, z30.s, z16.s\n"
    "fmin z31.s, p3/M, z31.s, z16.s\n"
    "st1w { z28.s }, p0, [x12, x28, LSL #2]\n"
    "st1w { z29.s }, p0, [x11, x28, LSL #2]\n"
    "st1w { z30.s }, p0, [x10, x28, LSL #2]\n"
    "st1w { z31.s }, p0, [x9, x28, LSL #2]\n"
    "blt 1b\n"
    "2:"  // Channel tail
    "movprfx z28, z18\n fmla z28.s, p3/M, z4.s, z9.s\n"
    "movprfx z29, z18\n fmla z29.s, p3/M, z3.s, z9.s\n"
    "ldr x22, [x15, #0x28]\n"
    "ldr x21, [x15, #0x30]\n"
    "movprfx z30, z18\n fmla z30.s, p3/M, z1.s, z9.s\n"
    "movprfx z31, z18\n fmla z31.s, p3/M, z0.s, z9.s\n"
    "ldr x27, [x15, #0x38]\n"
    "ldr x20, [x15, #0x48]\n"
    "ldr x26, [x15, #0x40]\n"
    "ldr x25, [x15, #0x50]\n"
    "incw x28\n"
    "mov p0.b, p2.b\n"
    "ld1w { z9.s }, p2/Z, [x22, x13, LSL #2]\n"
    "ldr x24, [x15, #0x58]\n"
    "fmla z28.s, p3/M, z0.s, z10.s\n"
    "fmla z29.s, p3/M, z2.s, z11.s\n"
    "ld1w { z11.s }, p2/Z, [x21, x13, LSL #2]\n"
    "ld1w { z10.s }, p2/Z, [x20, x13, LSL #2]\n"
    "fmla z30.s, p3/M, z2.s, z12.s\n"
    "fmla z31.s, p3/M, z1.s, z12.s\n"
    "ldr x23, [x15, #0x60]\n"
    "ldr x22, [x15, #0x68]\n"
    "ldr x21, [x15, #0x70]\n"
    "fmla z28.s, p3/M, z5.s, z12.s\n"
    "fmla z29.s, p3/M, z4.s, z12.s\n"
    "ld1w { z12.s }, p2/Z, [x27, x13, LSL #2]\n"
    "ldr x20, [x15, #0x78]\n"
    "fmla z30.s, p3/M, z6.s, z9.s\n"
    "ld1w { z9.s }, p2/Z, [x26, x13, LSL #2]\n"
    "fmla z31.s, p3/M, z3.s, z13.s\n"
    "fmla z28.s, p3/M, z7.s, z13.s\n"
    "fmla z29.s, p3/M, z6.s, z13.s\n"
    "fmla z30.s, p3/M, z4.s, z13.s\n"
    "fmla z31.s, p3/M, z8.s, z11.s\n"
    "ld1w { z11.s }, p2/Z, [x25, x13, LSL #2]\n"
    "fmla z28.s, p3/M, z1.s, z12.s\n"
    "fmla z29.s, p3/M, z0.s, z12.s\n"
    "ld1w { z12.s }, p2/Z, [x24, x13, LSL #2]\n"
    "fmla z30.s, p3/M, z5.s, z10.s\n"
    "fmla z31.s, p3/M, z4.s, z10.s\n"
    "fmla z28.s, p3/M, z2.s, z9.s\n"
    "fmla z29.s, p3/M, z1.s, z9.s\n"
    "ld1w { z9.s }, p2/Z, [x23, x13, LSL #2]\n"
    "fmla z30.s, p3/M, z0.s, z11.s\n"
    "fmla z31.s, p3/M, z2.s, z12.s\n"
    "fmla z28.s, p3/M, z8.s, z10.s\n"
    "fmla z29.s, p3/M, z7.s, z10.s\n"
    "ld1w { z10.s }, p2/Z, [x22, x13, LSL #2]\n"
    "fmla z30.s, p3/M, z3.s, z9.s\n"
    "fmla z31.s, p3/M, z5.s, z10.s\n"
    "fmla z28.s, p3/M, z3.s, z11.s\n"
    "ld1w { z11.s }, p2/Z, [x21, x13, LSL #2]\n"
    "fmla z29.s, p3/M, z5.s, z12.s\n"
    "ld1w { z12.s }, p2/Z, [x20, x13, LSL #2]\n"
    "fmla z30.s, p3/M, z7.s, z11.s\n"
    "fmla z31.s, p3/M, z6.s, z11.s\n"
    "fmla z28.s, p3/M, z6.s, z9.s\n"
    "fmla z29.s, p3/M, z8.s, z10.s\n"
    "fmla z30.s, p3/M, z8.s, z12.s\n"
    "fmla z31.s, p3/M, z7.s, z12.s\n"
    "fmax z28.s, p3/M, z28.s, z17.s\n"
    "fmax z29.s, p3/M, z29.s, z17.s\n"
    "fmin z28.s, p3/M, z28.s, z16.s\n"
    "fmin z29.s, p3/M, z29.s, z16.s\n"
    "fmax z30.s, p3/M, z30.s, z17.s\n"
    "fmax z31.s, p3/M, z31.s, z17.s\n"
    "st1w { z28.s }, p0, [x12, x28, LSL #2]\n"
    "st1w { z29.s }, p0, [x11, x28, LSL #2]\n"
    "fmin z30.s, p3/M, z30.s, z16.s\n"
    "fmin z31.s, p3/M, z31.s, z16.s\n"
    "st1w { z30.s }, p0, [x10, x28, LSL #2]\n"
    "st1w { z31.s }, p0, [x9, x28, LSL #2]\n"
    :
    : [n_channels] "r" ((unsigned long) n_channels), [offsetof_Args_inptrs] "I" (offsetof(Args, inptrs)), [offsetof_args_max] "I" (offsetof(Args, max)), [offsetof_args_min] "I" (offsetof(Args, min)), [offsetof_args_outptrs] "I" (offsetof(Args, outptrs)), [offsetof_args_params] "I" (offsetof(Args, params)), [params_struct] "r" (&params_struct)
    : "cc", "memory", "p0", "p1", "p2", "p3", "x9", "x10", "x11", "x12", "x13", "x14", "x15", "x16", "x20", "x21", "x22", "x23", "x24", "x25", "x26", "x27", "x28", "z0", "z1", "z2", "z3", "z4", "z5", "z6", "z7", "z8", "z9", "z10", "z11", "z12", "z13", "z16", "z17", "z18", "z28", "z29", "z30", "z31"
  );
}

}  // namespace depthwise
}  // namespace ops
}  // namespace kai

#endif  // defined(__aarch64__)
